from airflow.plugins_manager import AirflowPlugin
from hooks.slack_webhook_hook import *
from operators.slack_webhook_operator import *
from utils.my_utils import *
                    
class PluginName(AirflowPlugin):
                    
    name = 'slack_plugin'
                    
    hooks = [slack_webhook_hook]
    operators = [slack_webhook_operator]